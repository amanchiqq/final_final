@extends('layouts.app')
@section('content')

    <link rel="mask-icon" href="https://halykbank.kz/themes/halyk/assets/safari-pinned-tab.svg" color="#5bbad5">

    <link rel="stylesheet" href="https://halykbank.kz/themes/halyk/assets/css/app-bd1ee729a0.css">

    <script charset="UTF-8" src="//web.webpushs.com/js/push/b7cb972be3cf56bbbd8e8178e357ab32_1.js" async></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-143519504-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-143519504-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-53PNJTK');</script>

<main class="content">

  <!-- begin fullpage__promo_block -->

  <!-- end fullpage__promo_block -->

  <section class="media__slider_top init init-multi">
    <div class="swiper-container swiper-container-fade swiper-container-initialized swiper-container-horizontal">
      <div class="swiper-wrapper" style="transition-duration: 700ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="5" style="width: 1018px; transition-duration: 700ms; opacity: 0; transform: translate3d(0px, 0px, 0px);">
        <div class="item__image hide-gradient" data-vibrant="">
          <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5ea/be7/a09/5eabe7a097949549624284.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5ea/be7/9b8/5eabe79b89598382969090.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/a24/90b/7ba/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5ea/be7/9b8/5eabe79b89598382969090.jpg&quot;);">
          </div>
        </div>
        <div class="item__slide">
          <div class="item__slider_content">
            <h1 class="color-green">
              Обменивайте<br>
              бонусы в<br>
              Sulpak выгодно</h1>
              <a href="https://halykbank.kz/promo/64" class="btn btn-secondary btn-large btn-yellow" style="color: black">
                Подробнее</a>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-swiper-slide-index="0" style="width: 1018px; transition-duration: 700ms; opacity: 0; transform: translate3d(-1018px, 0px, 0px);">
            <div class="item__image hide-gradient" data-vibrant="">
              <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5ea/fb0/947/5eafb09473b90362057690.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5ea/fb0/8e0/5eafb08e0a9fe802859687.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/a3c/e8c/409/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5ea/fb0/8e0/5eafb08e0a9fe802859687.jpg&quot;);">
              </div>
            </div>
            <div class="item__slide">
              <div class="item__slider_content">
                <h1 class="color-white">
                  Технические работы<br>
                  с 02:00 7 мая<br>
                  до 08:00 10 мая</h1>
                  <a href="https://halykbank.kz/about/press_center/news/9197" class="btn btn-secondary btn-large btn-yellow" style="color: black">
                    Подробнее</a>
                  </div>
                </div>
              </div>
              <div class="swiper-slide" data-swiper-slide-index="1" style="width: 1018px; transition-duration: 700ms; opacity: 0; transform: translate3d(-2036px, 0px, 0px);">
                <div class="item__image hide-gradient" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(200, 196, 184) 0%, rgb(188, 172, 156) 100%);">
                  <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5eb/28d/426/5eb28d426e4de078985276.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5eb/28d/38d/5eb28d38d01ce340433891.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/e72/70f/7d7/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5eb/28d/38d/5eb28d38d01ce340433891.jpg&quot;);">
                  </div>
                </div>
                <div class="item__slide">
                  <div class="item__slider_content">
                    <h1 class="color-green">
                      Помощь жителям Мактааральского района</h1>
                      <a href="https://halykbank.kz/about/press_center/news/9200" class="btn btn-secondary btn-large btn-yellow" style="color: black">
                        Подробнее</a>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="2" style="width: 1018px; transition-duration: 700ms; opacity: 0; transform: translate3d(-3054px, 0px, 0px);">
                    <div class="item__image hide-gradient" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(250, 194, 23) 0%, rgb(16, 104, 76) 100%);">
                      <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5e9/99e/675/5e999e67597a3383529925.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5e9/996/781/5e9996781d690602880304.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/35f/4b2/c00/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5e9/996/781/5e9996781d690602880304.jpg&quot;);">
                      </div>
                    </div>
                    <div class="item__slide">
                      <div class="item__slider_content">
                        <h1 class="color-white">
                          Депозиты<br>
                          надежного<br>
                          банка</h1>
                          <a href="https://halykbank.kz/deposit/srochnye-vklady" class="btn btn-secondary btn-large btn-primary" style="color: white">
                            Онлайн открытие</a>
                          </div>
                        </div>
                      </div>
                      <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="3" style="width: 1018px; transition-duration: 700ms; opacity: 1; transform: translate3d(-4072px, 0px, 0px);">
                        <div class="item__image hide-gradient" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(206, 216, 148) 0%, rgb(252, 209, 4) 100%);">
                          <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5e8/809/d90/5e8809d909465595611229.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5e8/809/c88/5e8809c88c37b918370653.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/0ba/a72/a7c/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5e8/809/c88/5e8809c88c37b918370653.jpg&quot;);">
                          </div>
                        </div>
                        <div class="item__slide">
                          <div class="item__slider_content">
                            <h1 class="color-white">
                              Полезная информация</h1>
                              <a href="https://halykbank.kz/card/rezhim" class="btn btn-secondary btn-large btn-yellow" style="color: black">
                                Ознакомиться</a>
                              </div>
                            </div>
                          </div>
                          <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="4" style="width: 1018px; transition-duration: 700ms; opacity: 0; transform: translate3d(-5090px, 0px, 0px);">
                            <div class="item__image hide-gradient" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(252, 252, 246) 0%, rgb(252, 252, 244) 100%);">
                              <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5e7/c9c/a01/5e7c9ca0164c0851396286.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5e7/c9c/9c8/5e7c9c9c8166d950036794.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/9ad/46e/ea0/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5e7/c9c/9c8/5e7c9c9c8166d950036794.jpg&quot;);">
                              </div>
                            </div>
                            <div class="item__slide">
                              <div class="item__slider_content">
                                <h1 class="color-white">
                                  Отсрочка<br>
                                  по кредитам</h1>
                                  <a href="https://halykbank.kz/credit/otsrochka" class="btn btn-secondary btn-large btn-yellow" style="color: black">
                                    Вся информация</a>
                                  </div>
                                </div>
                              </div>
                              <div class="swiper-slide" data-swiper-slide-index="5" style="width: 1018px; transition-duration: 700ms; opacity: 0; transform: translate3d(-6108px, 0px, 0px);">
                                <div class="item__image hide-gradient" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(252, 242, 196) 0%, rgb(252, 92, 100) 100%);">
                                  <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5ea/be7/a09/5eabe7a097949549624284.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5ea/be7/9b8/5eabe79b89598382969090.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/a24/90b/7ba/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5ea/be7/9b8/5eabe79b89598382969090.jpg&quot;);">
                                  </div>
                                </div>
                                <div class="item__slide">
                                  <div class="item__slider_content">
                                    <h1 class="color-green">
                                      Обменивайте<br>
                                      бонусы в<br>
                                      Sulpak выгодно</h1>
                                      <a href="https://halykbank.kz/promo/64" class="btn btn-secondary btn-large btn-yellow" style="color: black">
                                        Подробнее</a>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" style="width: 1018px; transition-duration: 700ms; opacity: 0; transform: translate3d(-7126px, 0px, 0px);">
                                    <div class="item__image hide-gradient" data-vibrant="">
                                      <div class="img lazy loaded" data-background-image="https://halykbank.kz/storage/app/uploads/public/5ea/fb0/947/5eafb09473b90362057690.jpg" data-background-image-sm="https://halykbank.kz/storage/app/uploads/public/5ea/fb0/8e0/5eafb08e0a9fe802859687.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/a3c/e8c/409/thumb__30_0_0_0_auto.jpg" data-loaded="true" style="background-image: url(&quot;https://halykbank.kz/storage/app/uploads/public/5ea/fb0/8e0/5eafb08e0a9fe802859687.jpg&quot;);">
                                      </div>
                                    </div>
                                    <div class="item__slide">
                                      <div class="item__slider_content">
                                        <h1 class="color-white">
                                          Технические работы<br>
                                          с 02:00 7 мая<br>
                                          до 08:00 10 мая</h1>
                                          <a href="https://halykbank.kz/about/press_center/news/9197" class="btn btn-secondary btn-large btn-yellow" style="color: black">
                                            Подробнее</a>
                                          </div>
                                        </div>
                                      </div></div>
                                      <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                                      <div class="section__carousel_controls">
                                        <div class="btn__carousel_prev" tabindex="0" role="button" aria-label="Previous slide"><i class="icon icon-chevron-left"></i></div>
                                        <div class="btn__carousel_next" tabindex="0" role="button" aria-label="Next slide"><i class="icon icon-chevron-right"></i></div>
                                        <div class="carousel__pagination swiper-pagination-clickable carousel__pagination_bullets">
                                          <span class="carousel__pagination_bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span>
                                          <span class="carousel__pagination_bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span>
                                          <span class="carousel__pagination_bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span><span class="carousel__pagination_bullet carousel__pagination_bullet_active" tabindex="0" role="button" aria-label="Go to slide 4"></span><span class="carousel__pagination_bullet" tabindex="0" role="button" aria-label="Go to slide 5"></span><span class="carousel__pagination_bullet" tabindex="0" role="button" aria-label="Go to slide 6"></span></div>
                                      </div>
                                    </section>
                                    <section class="section section__exchange_rates">
                                      <div class="section__exchange_rates_wrap">
                                        <div class="section__title">
                                          <h1>Курсы валют</h1>
                                        </div>
                                        <div id="_js_currency_widget" class="exchange__rates_cont"><div class="exchange_rates"><div class="currency__columns"><div class="currency__column"><div class="currency__title">USD</div> <div class="currency__group"><div class="currency__value up">420.6</div> <div class="currency__value down">426.47</div></div></div><div class="currency__column"><div class="currency__title">EUR</div> <div class="currency__group"><div class="currency__value up">453.53</div> <div class="currency__value down">460.28</div></div></div><div class="currency__column"><div class="currency__title">RUB</div> <div class="currency__group"><div class="currency__value up">5.43</div> <div class="currency__value down">6</div></div></div></div> <div class="exchange__rates_footer"><span class="mutted"></span> <a href="https://halykbank.kz/exchange-rates">Все курсы валют <i class="icon icon-chevron-right"></i></a></div></div> <div class="currency__converter"><div class="form__block"><div class="converter__title">Конвертер валют</div> <div class="form__group"><div class="form__select_group"><input placeholder="" type="tel" class="form-control"> <div class="simple-dropdown"><div class="component-dropdown"><div class="component__select"><span class="component__select--name">₸</span></div> <!----></div></div></div> <div class="form__select_group"><input type="text" readonly="readonly" class="form-control"> <div class="simple-dropdown"><div class="component-dropdown"><div class="component__select"><span class="component__select--name">$</span></div> <!----></div></div></div></div></div></div></div>
                                      </div>
                                    </section>

                                    <section class="section section__index__products_card">
                                      <div class="section__title">
                                        <h1>Продукты на все случаи жизни</h1>
                                      </div>
                                      <div class="section__products_card_wrap">
                                        <div class="swiper-container swiper-container-initialized swiper-container-horizontal">
                                          <div class="swiper-wrapper">
                                            <div class="swiper-slide swiper-slide-active" style="width: 250.5px;">
                                              <div class="product__card">
                                                <div class="product__card_wrap">
                                                  <div class="card__img" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(211, 221, 163) 0%, rgb(207, 221, 173) 100%);">
                                                    <div class="img lazy" data-background-image="https://halykbank.kz/storage/app/uploads/public/3bd/f61/02e/thumb__544_332_0_0_auto.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/3bd/f61/02e/thumb__30_0_0_0_auto.jpg">
                                                    </div>
                                                  </div>
                                                  <div class="card__item_content">
                                                    <div class="card__item_content_wrap">
                                                      <div class="card__title">Полезная информация</div>
                                                      <a href="https://halykbank.kz/card/rezhim" class="btn btn-primary btn-hollow btn-block">Ознакомиться</a>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="swiper-slide swiper-slide-next" style="width: 250.5px;">
                                              <div class="product__card">
                                                <div class="product__card_wrap">
                                                  <div class="card__img" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(16, 122, 18) 0%, rgb(178, 149, 28) 100%);">
                                                    <div class="img lazy" data-background-image="https://halykbank.kz/storage/app/uploads/public/48b/9ec/3cb/thumb__544_332_0_0_auto.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/48b/9ec/3cb/thumb__30_0_0_0_auto.jpg">
                                                    </div>
                                                  </div>
                                                  <div class="card__item_content">
                                                    <div class="card__item_content_wrap">
                                                      <div class="card__title">5% бонусов</div>
                                                      <div class="list_style">
                                                        <ul>
                                                          <li>В супермаркетах и аптеках</li>
                                                          <li>За доставку еды и на платежи в Homebank</li>
                                                        </ul>
                                                      </div>
                                                      <a href="https://halykbank.kz/promo/58" class="btn btn-primary btn-hollow btn-block">Подробнее</a>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="swiper-slide" style="width: 250.5px;">
                                              <div class="product__card">
                                                <div class="product__card_wrap">
                                                  <div class="card__img" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(249, 249, 249) 0%, rgb(247, 221, 23) 100%);">
                                                    <div class="img lazy" data-background-image="https://halykbank.kz/storage/app/uploads/public/8df/fce/ad7/thumb__544_332_0_0_auto.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/8df/fce/ad7/thumb__30_0_0_0_auto.jpg">
                                                    </div>
                                                  </div>
                                                  <div class="card__item_content">
                                                    <div class="card__item_content_wrap">
                                                      <div class="card__title">Доставим карту бесплатно</div>
                                                      <div class="list_style">
                                                        <ul>
                                                          <li>Бесплатная доставка</li>
                                                          <li>Нур-Султан и Алматы</li>
                                                        </ul>
                                                      </div>
                                                      <a href="https://halykbank.kz/kz/bonuscard" class="btn btn-primary btn-hollow btn-block">Заказать карту</a>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="swiper-slide" style="width: 250.5px;">
                                              <div class="product__card">
                                                <div class="product__card_wrap">
                                                  <div class="card__img" data-vibrant="">
                                                    <div class="img lazy" data-background-image="https://halykbank.kz/storage/app/uploads/public/0a4/5c6/968/thumb__544_332_0_0_auto.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/0a4/5c6/968/thumb__30_0_0_0_auto.jpg">
                                                    </div>
                                                  </div>
                                                  <div class="card__item_content">
                                                    <div class="card__item_content_wrap">
                                                      <div class="card__title">Установите Homebank.kz</div>
                                                      <div class="list_style">
                                                        <ul>
                                                          <li>Без посещения отделений</li>
                                                          <li>Сотни услуг без комиссий</li>
                                                        </ul>
                                                      </div>
                                                      <a href="https://homebank.kz/" class="btn btn-primary btn-hollow btn-block">Установить приложение</a>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="swiper-slide" style="width: 250.5px;">
                                              <div class="product__card">
                                                <div class="product__card_wrap">
                                                  <div class="card__img" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(29, 113, 51) 0%, rgb(120, 160, 53) 100%);">
                                                    <div class="img lazy" data-background-image="https://halykbank.kz/storage/app/uploads/public/00b/169/cf7/thumb__544_332_0_0_auto.jpg" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/00b/169/cf7/thumb__30_0_0_0_auto.jpg">
                                                    </div>
                                                  </div>
                                                  <div class="card__item_content">
                                                    <div class="card__item_content_wrap">
                                                      <div class="card__title">1% бонус на все карты</div>
                                                      <div class="list_style">
                                                        <ul>
                                                          <li>На все платежи</li>
                                                          <li>На все карты</li>
                                                        </ul>
                                                      </div>
                                                      <a href="https://halykbank.kz/bonuscard" class="btn btn-primary btn-hollow btn-block">Подробнее</a>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                                          <div class="section__carousel_controls">
                                            <div class="carousel__pagination carousel__pagination_primary carousel__pagination_center swiper-pagination-clickable carousel__pagination_bullets"><span class="carousel__pagination_bullet carousel__pagination_bullet_active" tabindex="0" role="button" aria-label="Go to slide 1"></span><span class="carousel__pagination_bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span></div>
                                          </div>
                                        </div>
                                      </section>


                                      <section class="section__index_promo_block">
                                        <div class="section__index_promo_block_wrap">
                                          <div class="promo__block_img" data-vibrant="" style="background-image: linear-gradient(135deg, rgb(160, 189, 220) 0%, rgb(170, 194, 220) 100%);">
                                            <div class="img lazy" data-background-image="https://halykbank.kz/storage/app/uploads/public/5be/e94/7ed/5bee947ed618f078418070.png" data-background-image-gradient="https://halykbank.kz/storage/app/uploads/public/8d8/1e9/d6e/thumb__30_0_0_0_auto.png">
                                            </div>
                                          </div>
                                          <div class="promo__block_content">

                                            <div class="section__title">
                                              <h1>Homebank.kz  #1</h1>
                                              <h3>4 000 000 клиентов Halyk уже используют Homebank.kz</h3>
                                            </div>

                                            <a href="https://halykbank.kz/homebank" class="btn btn-secondary btn-large" target="_blank">Мне тоже пора</a>
                                          </div>
                                        </div>
                                      </section>
                                    </main>
                                    <script src="https://halykbank.kz/themes/halyk/assets/js/fullpage-2410ca0209.js"></script>
<script src="https://halykbank.kz/themes/halyk/assets/js/vendor-12c7dd88f8.js"></script>
<script src="https://halykbank.kz/themes/halyk/assets/js/app-db9586275f.js"></script>
<script src="https://halykbank.kz/modules/system/assets/js/framework.combined-min.js"></script>
<link rel="stylesheet" property="stylesheet" href="https://halykbank.kz/modules/system/assets/css/framework.extras-min.css">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-53PNJTK"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
                                    @endsection
